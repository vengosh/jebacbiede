//module "chujowideweloperzy.js"

class Portal {
		constructor(guid, name, hpstart, hpcurr, modstart, modcurr, mon, alerted) {
			this.guid = guid;
			this.name = name;
			this.hpstart = hpstart;
			this.hpcurr = hpcurr;
			this.modstart = modstart;
			this.modcurr = modcurr;
			this.mon = mon;
			this.alerted = alerted;		
		}
	}
	