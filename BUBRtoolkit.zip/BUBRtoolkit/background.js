//background.js
chrome.action.onClicked.addListener(
	function (tab) {
			chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => 
			{
				let url = tabs[0].url
				if(url.includes("intel.ingress.com")){
					chrome.tabs.sendMessage(tabs[0].id, { type: "popup-modal" });
				}else{
					chrome.notifications.create({
						type: 'basic',
						iconUrl: 'bobrownik_160.png',
						title: 'NIE WESZŁEŚ',
						message: "Ingress Intel Tab not found!",
						priority: 1
					});
				}				
			})
	});