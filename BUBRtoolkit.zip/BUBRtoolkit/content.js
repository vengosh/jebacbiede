window.portalList = [];
window.getCookie = function(name) {
	var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
	if (match) return match[2];
}
var v = "";
var token = getCookie("csrftoken");
for(let x = 0; x < document.scripts.length; x++){
		var script = document.scripts[x].src;
		if(script.includes("gen_dashboard"))
			v = script.replace('https://intel.ingress.com/jsc/gen_dashboard_','').replace('.js','');
}

function _getPortals(){
	return window.portalList;
}

function getPortalName(portalGuid){
	var retVal = "";	
	//var portalGuid = "1313ee2c862940728401ba9268fb20c0.16";
	$.ajax({
		beforeSend: function(request) {
			request.setRequestHeader("accept", '*/*');
			request.setRequestHeader("accept-language", 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7');
			request.setRequestHeader("content-type", 'application/json; charset=UTF-8');
			request.setRequestHeader("x-csrftoken", token);
		},
		async: false,
		contentType: "application/json",
		dataType: "json",
		method: "POST",
		url: '/r/getPortalDetails',
		referrer: "https://intel.ingress.com/",
		referrerPolicy: "strict-origin-when-cross-origin",
		data: "{\"guid\":\""+portalGuid+"\",\"v\":\""+v+"\"}",
		mode: "cors",
		credentials: "include",
		success: function(data) {
			//console.log( data );
			var res = data?.result?.[8];
			retVal = (typeof res === "undefined" ? "CHUJ WIE - NIE WESZŁEŚ!" : res);
		}
	});
	return retVal;
}	 
	
function paczajNaPortal() {
	var portalGuid = window.Jl?.c.i;
	if(typeof portalGuid !== "undefined")
	{
		let data = window.portalList.find(object => object['guid'] === portalGuid);
		if(typeof data === 'undefined'){		
			window.portalList.push(new Portal(portalGuid,getPortalName(portalGuid),-1,-1,-1,-1,false,false));			
			//console.log(data);
		}
		else
		{
			alert("NIE WESZŁEŚ! portal jest już w monitoringu!");
		}
	}
	else
		alert("NIE WESZŁEŚ! najpierw wybierz portal gamoniu!");
}

function test(){
	console.log($("#papap"));
	//console.log(document.getElementById("popup-content").contentWindow);
	//localStorage.setItem("chuj","dupa");
}

let btn = document.createElement("button");
let dialog = document.createElement("div");

btn.className = "wgbutton";
btn.innerHTML = "ADD PORTAL";
btn.onclick = test;//paczajNaPortal;

dialog.id = "papap";

document.body.firstElementChild.appendChild(btn);
document.body.firstElementChild.appendChild(dialog);


