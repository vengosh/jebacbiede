//content.js
var injected = false;

chrome.runtime.onMessage.addListener((request) => {
	if (request.type === 'popup-modal') {
		showModal();
	}else if(request.type == "chuj"){
		var $ = jQuery;
		$().toastmessage('showToast', {
				text: 'asasasasasas',
				type: 'notice',
				position: 'middle-center'
			});
	}
});

const showModal = () => {
	if(!injected){
		const modal = document.createElement("dialog");
		modal.setAttribute(
			"style", "height:auto;border: none;top:150px;border-radius:20px;background-color:white;position: fixed; box-shadow: 0px 12px 48px rgba(29, 5, 64, 0.32);"
		);
		modal.innerHTML = "<iframe id=\"popup-content\" sandbox=\"allow-same-origin allow-popups allow-scripts allow-top-navigation\" style=\"height:100%;width:75em;\"></iframe>;<div style=\"position:absolute; top:0px; left:5px;\"><button style=\"padding: 8px 12px; font-size: 16px; border: none; border-radius: 20px;\">x</button></div>";
		document.body.appendChild(modal);
		const dialog = document.querySelector("dialog");
		dialog.showModal();
		const iframe = document.getElementById("popup-content");
		iframe.src = chrome.runtime.getURL("PortalWatchdog.html");
		iframe.frameBorder = 0;
		dialog.querySelector("button").addEventListener("click", () => {
			dialog.close();
		});
		injected = true;
	}else{
		const dialog = document.querySelector("dialog");
		dialog.showModal();
	}
}

// const showModal2 = () => {
	// var $ = jQuery;

	// $("#papap").kendoWindow({
	  // content: {
		// url: chrome.runtime.getURL("PortalWatchdog.html"),
		// iframe: true,
		// visible: true
	  // }
	// });
// }


function injectScript(file_path, tag) {
    var node = document.getElementsByTagName(tag)[0];
    var script = document.createElement('script');
    script.setAttribute('type', 'text/javascript');
    script.setAttribute('src', file_path);
    node.appendChild(script);
}

function jqLoad(){
	setTimeout(function() {
		jQuery.noConflict(); 
		//console.log('jQuery loaded'); 
		//console.log(typeof $);
		//console.log(typeof jQuery); 		
	}, 1000);
	void(0);
}

function injectJquery(file_path, tag, integrity) {
    var node = document.getElementsByTagName(tag)[0];
    var script = document.createElement('script');
    script.setAttribute('src', file_path);
	script.setAttribute('integrity', integrity);
	script.setAttribute('crossorigin', "anonymous");
	script.onload = jqLoad;
    node.appendChild(script);
}

injectScript(chrome.runtime.getURL('content.js'), 'body');
injectScript(chrome.runtime.getURL('IngressPortalClass.js'), 'body');
//injectScript(chrome.runtime.getURL('toast.js'), 'body');
injectJquery(chrome.runtime.getURL('jquery.js'), 'body',"sha256-2krYZKh//PcchRtd+H+VyyQoZ/e3EcrkxhM8ycwASPA=");
injectJquery(chrome.runtime.getURL('jqueryui.js'), 'body',"sha256-lSjKY0/srUM9BE3dPm+c4fBo1dky2v27Gdjm2uoZaL0=");


