var _CHUJ = "chuj";
window.portalList = [];
window.portalList.push(new Portal("1d6d895f4fef43999c9f897834666f73.16","pani fisz",100,100,0,0,true,false));
window.portalList.push(new Portal("1313ee2c862940728401ba9268fb20c0.16","holokaust",80,80,2,2,true,false)); 
const PortalStatus = 
{
	Active: '<span class="status text-activeyellow">&bull;</span> Active | RN</td>',
	ActiveHealthy: '<span class="status text-activegreen">&bull;</span> Active | OK</td>',
	Disabled: '<span class="status text-inactive">&bull;</span> Disabled</td>',
	UnderAttack: '<span class="status text-attack">&bull;</span> Active | UNDER ATTACK!</td>',
	Killed: '<span class="status text-killed">&bull;</span> Active | DEAD</td>'
}

function bindData() {
	const pTable = $("#prtTable");
	$("#prtTable > tbody").empty();

	for(let por = 0; por < window.portalList.length; por++){
		let idx = por+1;
		let p = window.portalList[por];
		let tRow = "<tr><td>";
		tRow += idx.toString();
		tRow += "</td>";        
		tRow += ("<td>#PNAME</td>").replace("#PNAME",p.name);		
		tRow += ("<td>#PHEALTH</td>").replace("#PHEALTH",p.hpcurr);		
		tRow += ("<td>#PMODC</td>").replace("#PMODC",p.modcurr);		
		tRow += "<td>";
		let statusCol = "";
		if(p.mon){			
			if(p.hpcurr == 100){
				statusCol = PortalStatus.ActiveHealthy;
			}else{
					if(p.hpcurr > 0){
						if(p.hpcurr != p.hpstart ){
							statusCol = PortalStatus.UnderAttack;
						}else{
							statusCol = PortalStatus.Active;
						}
				}else{
					statusCol = PortalStatus.Killed;
				}
			}
		}else{
			statusCol = PortalStatus.Disabled;
		}
		tRow += statusCol;
		tRow += "<td>";		
		let fCol = '<a data-item="#GUID" data-event="toggle" href="#" class="featurecol monitor" title="Paczaj / Nie paczaj" data-toggle="tooltip"><i class="material-icons">&#xE1D2;</i></a>';
		fCol += '<a data-item="#GUID" data-event="delete" href="#" class="featurecol delete" title="Wypierdol z listy" data-toggle="tooltip"><i class="material-icons">&#xE5C9;</i></a></td>';
        fCol = fCol.replace("#GUID",p.guid).replace("#GUID",p.guid);                   
        tRow += fCol;
		tRow += "</tr>";                      
		pTable.append(tRow);
	}
	$("#prtTable .featurecol").click(function() {
		var btn = $(this);
		let itmGuid = btn.data("item");
		let evnt = btn.data("event");
		var dataItem = window.portalList.find(item => item.guid === itmGuid);
		if(evnt == "toggle"){
			//window.portalList = window.portalList.filter(portal => portal.guid == );
			dataItem.mon = !dataItem.mon;
			bindData();
		}else{
			window.portalList = window.portalList.filter(portal => portal.guid == itmGuid);
			bindData();
		}
	});
}

function getportalList() {
	if(window.portalList?.length !== "undefined" && window.portalList?.length > 0){
		var prt1 = new Portal("1d6d895f4fef43999c9f897834666f73.16","pani fisz",100,100,0,0,true,false);
		var prt2 = new Portal("1313ee2c862940728401ba9268fb20c0.16","holokaust",80,80,2,2,true,false); 
		window.portalList.push(prt1);
		window.portalList.push(prt2);		
		console.log(window.portalList);
	}
	
}
	
async function doMagic() {
	window.getCookie = function(name) {
		var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
		if (match) return match[2];
	}
	
	window.sleep = function(ms) {
			return new Promise(resolveFunc => setTimeout(resolveFunc, ms));
	}
	
	window.sprawdz = async function(portal) {
		if(portal.mon){  
				const response = await fetch("https://intel.ingress.com/r/getPortalDetails", {
					"headers": {
					"accept": "*/*",
					"accept-language": "pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7",
					"content-type": "application/json; charset=UTF-8",
					"sec-ch-ua": "\"Google Chrome\";v=\"105\", \"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"105\"",
					"sec-ch-ua-mobile": "?0",
					"sec-ch-ua-platform": "\"windows\"",
					"sec-fetch-dest": "empty",
					"sec-fetch-mode": "cors",
					"sec-fetch-site": "same-origin",
					"x-csrftoken": token
					},
					"referrer": "https://intel.ingress.com/?state=GOOGLE&code=4%2F0ARtbsJpyA6ig2XW5Iqw-Gwox0tR68gK2CSKbYDain0P4pAzH_8jwv6gI-VBm0IV86p2ubA&scope=email+profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile+openid&authuser=0&prompt=consent",
					"referrerPolicy": "strict-origin-when-cross-origin",
					"body": "{\"guid\":\""+portal.guid+"\",\"v\":\""+v+"\"}",
					"method": "POST",
					"mode": "cors",
					"credentials": "include"
				});
				
			  
				try{
					const result = await response.json();			
					//console.log('OK! ', result);
					console.log('PORTAL ### '+portal.name+' SPRAWDZONY! ', result["result"][5]);
					let currenthp = result["result"][5];
					let currentmod = result["result"][14].length ??  0;
					if((currenthp != portal.hpcurr && portal.hpcurr != -1) || (currentmod != portal.modcurr && portal.modcurr != -1))
					{
						var d = new Date(Date.now());			
						alert(d.toTimeString() + ' | NAKURWIAJĄ W PORTAL ### '+portal.name+' ! ');
						portal.alerted = true;
					}
					portal.hpcurr = currenthp;
					portal.modcurr = currentmod;
					//return result;
				}catch(err){
					console.log('CPNT! ' + err);
				}
			}
	}
	
	window.checkPortal = async function(portal) {				
		await sprawdz(portal);	
	}

	//window.portalsList = [];
	
	var portals = window.portalsList ?? [];
	var intervalMs = 2000;
	var v = "";
	var token = getCookie("csrftoken");

	for(let x = 0; x < document.scripts.length; x++){
		var script = document.scripts[x].src;
		if(script.includes("gen_dashboard"))
			v = script.replace('https://intel.ingress.com/jsc/gen_dashboard_','').replace('.js','');
	}		 
	 
	for (let x = 0; x < 5; x++){
		for(const chuj of portals){
			checkPortal(chuj);
		} 
		await sleep(intervalMs);    
    };
	
	getportalList();
}

function saveConfig() {
	chrome.storage.sync.set({"portals": window.portalList});
}

function loadConfig(){
	//chrome.storage.sync.get(["portals"]).then((result) => {
	const portals = chrome.storage.sync.get(['portals']);
	if(typeof window.portalList !== "undefined")
		window.portalList = portals;	 
}

async function RedeemPasscodes() {

	var rdm = prompt().split(/\r?\n/);
	window.getCookie = function(name) {
	  var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
	  if (match) return match[2];
	}

	function sleep(ms) {
	  return new Promise(resolveFunc => setTimeout(resolveFunc, ms));
	}

	var v = "";
	for(let x = 0; x < document.scripts.length; x++){
		var script = document.scripts[x].src;
		if(script.includes("gen_dashboard"))
			v = script.replace('https://intel.ingress.com/jsc/gen_dashboard_','').replace('.js','');
	}

	var token = getCookie("csrftoken");
	var itmCnt = 100;

	async function nakurwiaj(paskot, fau, token, rep){

		const response = await fetch("/r/redeemReward", {
			"credentials": "include",
			"headers": {
				"User-Agent": "Mozilla/5.0 (X11; Linux aarch64; rv:68.0) Gecko/20100101 Firefox/68.0",
				"Accept": "*/*",
				"Accept-Language": "en-US,en;q=0.5",
				"Content-Type": "application/json; charset=utf-8",
				"X-CSRFToken": token
			},
			"referrer": "https://intel.ingress.com/",
			"body": "{\"passcode\":\""+paskot+"\",\"v\":\""+fau+"\"}",
			"method": "POST",
			"mode": "cors"
		});
		
		if (!response.ok) {
			if(!rep){
				console.log('CPNT! KOD: '+paskot+' = nie weszłeś! .... RETRYING IN 5 SEC! ');
				await sleep(5000);
				nakurwiaj(paskot, fau, token, true);
			}else{
				console.log('CPNT! KOD: '+paskot+' = nie weszłeś po raz drugi! .... I GIVE UP, WPISZ SE RĘCZNIE! :D ');
			}
		}

		try{
			const result = await response.json();
			await sleep(3000);
			console.log('OK! KOD: '+paskot+' nakurwiony! ', result);
			//return result;
		}catch(err){
			console.log('CPNT! KOD: '+paskot+' sie zjebal! ');
		}
	}


	for (let x1 = 0; x1 < rdm.length; x1++){
		await nakurwiaj(rdm[x1],v, token, false);        
	};
}

async function redeemClick(){
	let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
	chrome.scripting.executeScript({
		target: { tabId: tab.id },
		function: RedeemPasscodes
	});
}

function StartMonitoring() {
	console.log("nakurwiam");
	//chrome.runtime.sendMessage(tabs[0].id, { type: "chuj" });
	chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => 
			{
				let url = tabs[0].url
				if(url.includes("intel.ingress.com")){
					chrome.tabs.sendMessage(tabs[0].id, { type: "chuj" });
				}	
			})
}





let btn = document.getElementById("monitorBtn");
let btn2 = document.getElementById("redeemBtn");
btn.addEventListener("click", StartMonitoring);
btn2.addEventListener("click", redeemClick);



$(document).ready(async function(){
	$('[data-toggle="tooltip"]').tooltip();
	//if(window.portalList.length == 0)
	let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
	chrome.scripting.executeScript({
		target: { tabId: tab.id },
		function: getportalList
	});
	bindData();	
});

document.body.addEventListener("load", async () => {
	let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
	chrome.scripting.executeScript({
		target: { tabId: tab.id },
		function: doMagic
	});
});




